package com.example.announcement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnnouncementApplicationTests {

	@Test
	void contextLoads() {
	}

}
