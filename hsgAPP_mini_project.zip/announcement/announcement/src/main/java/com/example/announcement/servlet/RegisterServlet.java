package com.example.announcement.servlet;



import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.announcement.User;
import com.example.announcement.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name="RegisterServlet", urlPatterns= {"/register"})
public class RegisterServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Autowired
	UserRepository repo;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);	
		RequestDispatcher rd = null;
		if(session != null && session.getAttribute("uname")!=null) {
			rd = req.getRequestDispatcher("/views/home.jsp");	 //home nh hai
		}else {
			rd = req.getRequestDispatcher("/WEB-INF/views/register.jsp");	
		}			
		
		rd.forward(req, resp);
		
//		req.getRequestDispatcher("/WEB-INF/views/register.jsp").forward(req, resp);
	}
	
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String uname = req.getParameter("username");
		String pass = req.getParameter("password");
		String hsgSociety=req.getParameter("hsgSociety"); 
		String bldgName=req.getParameter("bldgName"); 
		String flatNum=req.getParameter("flatNum"); 
	       
		
		PrintWriter out = resp.getWriter();
		
//		User user = repo.findByUsernameAndPassword(uname, pass);
		User user=repo.findByUsername(uname);
		if(user != null) {
			out.write("<h1>User Already registered</h1>");
			out.write("<br><a href=register>Click here to go back</a>");
			out.write("<br><a href=login>Click here to Log-In</a>");
			
		}else {
			repo.save(new User(uname,pass,hsgSociety,flatNum,bldgName,5,2023,0));
			req.getRequestDispatcher("/WEB-INF/views/login.jsp").forward(req, resp);
		}
	}

}
