package com.example.announcement.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.announcement.User;
import com.example.announcement.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet(name="AddwalletServlet", urlPatterns= {"/addwallet"})
public class Addwallet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	@Autowired
	UserRepository repo;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);	
		RequestDispatcher rd = null;
		if(session != null && session.getAttribute("username")!=null) {
			rd = req.getRequestDispatcher("/WEB-INF/views/AddWallet.jsp");	// ..home nh hai 
		}else {
			rd = req.getRequestDispatcher("/WEB-INF/views/login.jsp");	
		}			
		
		rd.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String amt  = req.getParameter("walletAmount");
		HttpSession session=req.getSession(false);
		
//		String uname = (String) session.getAttribute("username");
//		String pass =(String) session.getAttribute("password");
//		User user = repo.findByUsernameAndPassword(uname, pass);
		User user =(User) session.getAttribute("user");
		Long userbal=user.getBal();
		long testamt=Long.parseLong(amt);
		
		PrintWriter out = resp.getWriter();
		user.setBal(userbal+testamt);
		repo.save(user);
		RequestDispatcher rd =req.getRequestDispatcher("/WEB-INF/views/home.jsp");
		rd.forward(req, resp);
		
		
	}
}
