package com.example.announcement.servlet;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.announcement.User;
import com.example.announcement.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet(name="HomeServlet", urlPatterns= {"/home"})
public class HomeServlet extends HttpServlet {
		
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Autowired
	UserRepository repo;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);	
		RequestDispatcher rd = null;
		String uname = (String) session.getAttribute("username");
		String pass =(String) session.getAttribute("password");
		
//		User user = repo.findByUsernameAndPassword(uname, pass);
//		String hsgSco = user.getHsgSociety();
//		String blgName=user.getBldgName();
//		String flatNum=user.getFlatNum();
//		Long month=user.getMonth();
//		Long year=user.getYear();
//		
//		req.setAttribute("hsgso","hsgSco");
//		req.setAttribute("blgname","blgName");
//		req.setAttribute("flatnum","flatNum");
//		req.setAttribute("month","month");
//		req.setAttribute("year","year");
//		req.setAttribute("user",user);
		
//		if(session != null && session.getAttribute("username")!=null) {
			rd = req.getRequestDispatcher("/WEB-INF/views/home.jsp");	// ..home nh hai 
//		}else {
//			rd = req.getRequestDispatcher("/WEB-INF/views/login.jsp");	
//		}			
		
		rd.forward(req, resp);
	}
}
