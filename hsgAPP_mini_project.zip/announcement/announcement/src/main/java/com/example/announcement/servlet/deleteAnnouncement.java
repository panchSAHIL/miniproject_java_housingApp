package com.example.announcement.servlet;

import java.io.IOException;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.announcement.Announcement;
import com.example.announcement.AnnouncementRepository;
import com.example.announcement.User;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name="deleteAnnouncement",urlPatterns = {"/updateToDoStatus/*"})
public class deleteAnnouncement extends HttpServlet{

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Autowired
	AnnouncementRepository repo;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);	
		 String pathInfo = req.getPathInfo();
		 User user1=(User) session.getAttribute("user");
		String admin=user1.getUsername().toLowerCase().toString();
		
		
		
		//to find the person who wrote the notice   + the admin who is sahil here
		
		
		
		if (pathInfo != null ) {
			
			
			 String[] pathSegments = pathInfo.split("/");
			 if (pathSegments.length > 0) {
	                String idstring =pathSegments[pathSegments.length - 1];
	                long id = Long.parseLong(idstring);
	                Optional<Announcement> ann=repo.findById(id);
	                String person=ann.get().getName();
	                
	                
	                
	                if (pathInfo != null && (admin.equals("sahil") || admin.equals(person))) {
//	       			 String[] pathSegments = pathInfo.split("/");
	       			 if (pathSegments.length > 0) {
//	       	                String idstring =pathSegments[pathSegments.length - 1];
//	       	                long id = Long.parseLong(idstring);
	       	                repo.deleteById(id);
	       	                resp.sendRedirect("/dashboard");
	       	                
	       			 }
	       		 }
	       		 else {
	       			 resp.sendRedirect("/dashboard");
	       		 }
	                
	                
	                
	                	
	          }                
	    }
		
	}
		
}
		
		//end
	
