package com.example.announcement.servlet;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name="utilityServlet",urlPatterns = {"/utility"} )
public class utility extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String Labelname=req.getParameter("utser");
		req.setAttribute("labelname", Labelname);
		RequestDispatcher rd=req.getRequestDispatcher("/WEB-INF/views/uti.jsp");
		
		rd.forward(req, resp);
	}
}
