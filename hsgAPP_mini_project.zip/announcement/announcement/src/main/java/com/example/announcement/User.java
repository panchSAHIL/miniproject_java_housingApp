package com.example.announcement;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column
    private Long id;
    @Column
    private String username;
    @Column
    private String password;
    @Column
    private String hsgSociety;
    @Column
    private String flatNum;
    @Column
    private String bldgName;
    @Column
    private Long month;
    @Column
    private Long year;
    @Column
    private Long bal;
	

    public User(Long id, String username, String password, String hsgSociety, String flatNum, String bldgName, Long month,
			Long year,Long bal) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.hsgSociety = hsgSociety;
		this.flatNum = flatNum;
		this.bldgName = bldgName;
		this.month = month;
		this.year = year;
		this.bal=bal;
	}
    
    

	public User(String username, String password, String hsgSociety, String flatNum2, String bldgName, int i,
			int j,int bal) {
		super();
		this.username = username;
		this.password = password;
		this.hsgSociety = hsgSociety;
		this.flatNum = flatNum2;
		this.bldgName = bldgName;
		this.month = (long) i;
		this.year = (long) j;
		this.bal=	(long) bal;
	}



	public String getHsgSociety() {
		return hsgSociety;
	}

	public void setHsgSociety(String hsgSociety) {
		this.hsgSociety = hsgSociety;
	}

	public String getFlatNum() {
		return flatNum;
	}

	public void setFlatNum(String flatNum) {
		this.flatNum = flatNum;
	}

	public String getBldgName() {
		return bldgName;
	}

	public void setBldgName(String bldgName) {
		this.bldgName = bldgName;
	}

	public Long getMonth() {
		return month;
	}

	public void setMonth(Long month) {
		this.month = month;
	}

	public Long getYear() {
		return year;
	}

	public void setYear(Long year) {
		this.year = year;
	}

	// Other user information fields and getters/setters
    public User() {
    	
    }
    
    public User(String uname,String pass) {
    	this.username = uname;
		this.password = pass;
    }

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}



	public Long getBal() {
		return bal;
	}



	public void setBal(Long bal) {
		this.bal = bal;
	}
	
    
    
}
