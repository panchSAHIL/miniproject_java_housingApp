package com.example.announcement.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.announcement.User;
import com.example.announcement.UserRepository;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;


@WebServlet(name="PaymentServlet", urlPatterns= {"/payment"})
public class Payment extends HttpServlet {
		
	
	private static final long serialVersionUID = 1L;
	
	@Autowired
	UserRepository repo;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session = req.getSession(false);	
		RequestDispatcher rd = null;
		if(session != null && session.getAttribute("username")!=null) {
			rd = req.getRequestDispatcher("/WEB-INF/views/payment.jsp");	// ..home nh hai 
		}else {
			rd = req.getRequestDispatcher("/WEB-INF/views/login.jsp");	
		}			
		
		rd.forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String amt  = req.getParameter("amount");
		HttpSession session=req.getSession(false);
//		RequestDispatcher rd = null;
//		if(session != null && session.getAttribute("username")!=null) {
//			rd = req.getRequestDispatcher("/WEB-INF/views/payment.jsp");	// ..home nh hai 
//		}else {
//			rd = req.getRequestDispatcher("/WEB-INF/views/login.jsp");	
//		}		
		
//		String uname = (String) session.getAttribute("username");
//		String pass =(String) session.getAttribute("password");
//		User user = repo.findByUsernameAndPassword(uname, pass);
		User user =(User) session.getAttribute("user");
		Long userbal=user.getBal();
		
		PrintWriter out = resp.getWriter();
		long testamt=Long.parseLong(amt);
		if(testamt!=550 || userbal<550) {
			out.write("<h1>Not valid Amount Or check your balance</h1>");
			out.write("<br><a href=payment>Click here to go back to payment</a>");
			out.write("<br><a href=home> Click here to go home</a>");
		}
		else {
			
//			Long testid=user.getId();
//			user.setBal(testamt);
			userbal=userbal-550;
			
			
			
			//added form here '
			Long mth=user.getMonth();
			if(mth>=12) {
				user.setMonth((long)1);
				user.setYear(user.getYear()+1);
			}
			else {
				user.setMonth(user.getMonth()+1);
			}
			
			
			
			
			
			//
			user.setBal(userbal);
			repo.save(user);
			RequestDispatcher rd =req.getRequestDispatcher("/WEB-INF/views/home.jsp");
			rd.forward(req, resp);
			

		}
		
	}
}
